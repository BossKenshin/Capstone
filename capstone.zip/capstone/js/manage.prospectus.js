var aid = localStorage.getItem('admin_id');

if(aid ==  null){
  window.location.replace("./index.html");

}

populateCourseDropdown();


function populateCourseDropdown() {
    $(document).ready(function () {
        $.ajax({
            url: "./sql_functions/fetch.course.php",
            success: function (data) {
                var result = JSON.parse(data);
                // alert("done saving data");


                    var element = document.getElementById("courses");

                    $("#courses").empty();

                    for (var i = 0; i < result.length; i++) {
                        let op = document.createElement("option");

                            op.value = result[i].course_id;
                            op.textContent = result[i].course_name + ' (' + result[i].course_abbreviation+')';
                            element.append(op);
                        
                    }


                
          

            }
        })
    });
}


$('#savePros').click(function(){

    var numFiles = $("#pdfFile")[0].files.length;



    var cid = document.getElementById('courses').value;

    if(cid != '' && numFiles != 0){
    var file_data = $('#pdfFile').prop('files')[0]; 
    
    var form_data = new FormData();//Fetch the file

    form_data.append('typeOfFunction', 'add');
    form_data.append('cid', cid);
    form_data.append('file', file_data);

    $.ajax({
        url: "./sql_functions/prospectus.functions.php",                      //Server api to receive the file
               type: "POST",
               dataType: 'script',
               cache: false,
               contentType: false,
               processData: false,
               data: form_data,
            success:function(dat2){
              if(dat2==0) 
              {
                Swal.fire({
                  icon: "success",
                  title: "Prospectus Added",
                });       
                populateCourseDropdown();

                // $('#gradesFileTable').DataTable().clear().destroy();
                // setGradesList();

                $('#pdfFile').val('');
              }
              else{
                Swal.fire({
                    icon: "error",
                    title: "Unable to upload ",
                  }); 
              } 
            }
      });
    }
    else{
        Swal.fire({
            icon: "error",
            title: "Fill out Form",
          }); 
    }

    $('#modalForAddProspectus').modal('hide');
})



$('#updatePros').click(function(){

    var numFiles = $("#pdfFile")[0].files.length;



    var cid = document.getElementById('courses').value;

    if(cid != '' && numFiles != 0){
    var file_data = $('#pdfFile').prop('files')[0]; 
    
    var form_data = new FormData();//Fetch the file

    form_data.append('typeOfFunction', 'update');
    form_data.append('cid', cid);
    form_data.append('file', file_data);

    $.ajax({
        url: "./sql_functions/prospectus.functions.php",                      //Server api to receive the file
               type: "POST",
               dataType: 'script',
               cache: false,
               contentType: false,
               processData: false,
               data: form_data,
            success:function(dat2){
              if(dat2==0) 
              {
                Swal.fire({
                  icon: "success",
                  title: "Prospectus Updated",
                });       
                populateCourseDropdown();

                $('#prospectusTable').DataTable().clear().destroy();
                setProspectusTable();

                $('#pdfFile').val('');
              }
              else{
                Swal.fire({
                    icon: "error",
                    title: "Unable to upload ",
                  }); 
              } 
            }
      });
    }
    else{
     Swal.fire({
                    icon: "error",
                    title: "Fill out Form",
                  }); 
    }

    $('#modalForAddProspectus').modal('hide');

})

setProspectusTable();

function setProspectusTable(){

  $.ajax({
    url: "./sql_functions/prospectus.functions.php",
    type: 'POST',
    data: 
    {
      typeOfFunction: 'fetch'
    },
    success: function (data) {
        var filesData = JSON.parse(data);

    if(filesData.length != 0){

              document.getElementById("prospectusTable").style.visibility = 'unset';


          $('#prospectusTable').DataTable({
              data: filesData,
              columns: [
                  { data: 'id'},
                  { data: 'prosfilename' },
                  { data: 'course_abb' }
              ],
              
  
          });

    }
    else{

        document.getElementById("gradesFileTable").style.visibility = 'hidden';
    }
    }
})



}