var tid = localStorage.getItem('teacher_id');
var fullname = localStorage.getItem('teacher_name');; 



if(tid ==  null && fullname == null) {
  window.location.replace("./index.html");
}





_deptDropdown2();

$("#btnbox2").click(function () {

    _deptDropdown2();
    $("#semSelect2").val("0").change();
    $("#subjectSelect2").empty();
    $("#courseSelect2").empty();
    $("#yearSelect2").val("1st").change();
})

function _deptDropdown2() {
  $(document).ready(function () {
    $.ajax({
      url: "./sql_functions/fetch.department.php",
      success: function (data) {
        var result = JSON.parse(data);
        // alert("done saving data");
        var element = document.getElementById("deptSelect2");
        $("#deptSelect2").empty();

        let ops = document.createElement("option");
        ops.value = "0";
        ops.hidden = true;
        ops.innerHTML = "Select Department";
        element.appendChild(ops);

        for (var i = 0; i < result.length; i++) {
          let op = document.createElement("option");

          if (
            result[i].dept_name != "Unassigned" &&
            result[i].dept_name != "Resigned"
          ) {
            op.value = result[i].dept_id;
            op.textContent = result[i].dept_name;

            element.append(op);
          }
        }
      },
    });
  });
}



$("#deptSelect2")
.change(function () {
$("#deptSelect2 option:selected").each(function () {
  // state here what happens if the selected option is selected
  var dept_id = $(this).val();
  var dept_name = $(this).text();

  //var elementDropdown = document.getElementById("chooseDept");

  _courseDropdown2(dept_name);
    $("#yearSelect2").val("1st").change();

  $("#semSelect2").val("0").change();
  $("#subjectSelect2").empty();


});
})
.change();



function _courseDropdown2(department) {
  $(document).ready(function () {
  $.ajax({
    url: "./sql_functions/fetch.course.php",
    success: function (data) {
      var result = JSON.parse(data);
      // alert("done saving data");
  
      var element = document.getElementById("courseSelect2");
  
      $("#courseSelect2").empty();
  
      let ops = document.createElement("option");
      ops.value = "0";
      ops.innerHTML = "Choose Course";
      element.appendChild(ops);
  
      for (var i = 0; i < result.length; i++) {
        let op = document.createElement("option");
  
        if (result[i].dept == department) {
          op.value = result[i].course_id;
          op.textContent = result[i].course_abbreviation;
  
          element.append(op);
        }
      }
    },
  });
  });
  }


  

$("#courseSelect2")
.change(function () {
$("#courseSelect2 option:selected").each(function () {
  // state here what happens if the selected option is selected


  //var elementDropdown = document.getElementById("chooseDept");

    $("#yearSelect2").val("1st").change();
 // $("#semSelect").val("0").change();
  $("#subjectSelect2").empty();


});
})
.change();



$("#yearSelect2")
.change(function () {
$("#yearSelect2 option:selected").each(function () {

  var sem = document.getElementById("semSelect2").value;
  var dept = document.getElementById("deptSelect2").value;
  var course = document.getElementById("courseSelect2").value;
  var year =  $(this).val();

  if(sem != 0 && dept != 0 && dept != "" && course != 0 && course != ""){
    $("#subjectSelect2").empty();

    _subjectDropdown2(dept, course, year, sem);

  }
  else{

  $("#semSelect2").val("0").change();
  $("#subjectSelect2").empty();

  }



});
})
.change();



  
$("#semSelect2")
.change(function () {
$("#semSelect2 option:selected").each(function () {
  // state here what happens if the selected option is selected
  var sem = $(this).val();
  var dept = document.getElementById("deptSelect2").value;
  var course = document.getElementById("courseSelect2").value;
  var year = document.getElementById("yearSelect2").value;

  


  //var elementDropdown = document.getElementById("chooseDept");
  if(sem != 0){
  _subjectDropdown2(dept, course, year, sem);
  }
  else{

    $("#subjectSelect2").empty();

  }


});
})
.change();




function _subjectDropdown2(department, course, year, semester) {
  $(document).ready(function () {
  $.ajax({
    url: "./sql_functions/teacher.fetch.subject.php",
    data:
    {
      "dept": department,
      "course": course,
      "year": year,
      "sem": semester
    },
    success: function (data) {
      var result = JSON.parse(data);
      // alert("done saving data");
  
      var element = document.getElementById("subjectSelect2");
  
      $("#subjectSelect2").empty();
  
      let ops = document.createElement("option");
      ops.value = "0";
      ops.innerHTML = "Choose Subject";
      element.appendChild(ops);
  
      for (var i = 0; i < result.length; i++) {
        let op = document.createElement("option");
  
          op.value = result[i].id;
          op.textContent = result[i].subject;
  
          element.append(op);
        
      }
    }
  });
  });
  }


  function setStudentSearchBar() {

    var course = document.getElementById("courseSelect2").value;
    var year = document.getElementById("yearSelect2").value;

    console.log(course + " " + year);

    $.ajax({
      url: "./sql_functions/fetch.list.student.pros.php",
      data:{
            course: course,
      },
      success: function (data) {
        var result = JSON.parse(data);

         console.log(result);

        var element = document.getElementById("studentList");

        $("#studentList").empty();


        for (var i = 0; i < result.length; i++) {
          let op = document.createElement("option");

            op.value = result[i].school_id;
            op.textContent = result[i].fullname;
            element.append(op);
          
        }




      }
    });
}


$("#submitSpecGrade").click(function() {

  var subject = document.getElementById("subjectSelect2").value;
  var stname = document.getElementById("stname").value;
  var grade  = document.getElementById("finalgrade").value
  var tid = 5;


  if(subject != "" && subject != 0 && stname != "" && stname != 0 && grade != "" && grade != 0 && tid != "") {

  $.ajax({
    url: "./sql_functions/upload.completion.php",                      //Server api to receive the file
           type: "GET",
           dataType: 'script',
           data: {
            "subject": subject,
            "stname": stname,
            "grade": grade,
           "tid": tid
           },
        success:function(dat2){
          if(dat2==1) 
          {
            Swal.fire({
              icon: "success",
              title: "Grade submitted ",
            });       

            _deptDropdown2();
            $("#semSelect2").val("0").change();
            $("#subjectSelect2").empty();
            $("#courseSelect2").empty();
            $("#yearSelect2").val("1st").change();
            $("#stname").val("");
            $("#finalgrade").val("");




            // $('#gradesFileTable').DataTable().clear().destroy();

            // setGradesList();
            
          }
          else alert("Unable to Upload");
        }
  });

}
else{
  Swal.fire({
    icon: "error",
    title: "Oops...",
    text: "Please fill out the missing details!!",
  });
}



});





setPendingTable();

function setPendingTable() {

    $(document).ready(function () {

        //var year = document.getElementById("StudentYear").value;
       


        $.ajax({
            url: "./sql_functions/fetch.pending.completion.list.php",
            data:
            {
                fullname: fullname

            },
            success: function (data) {


                var pendingData = JSON.parse(data);



                $('#completionTable').DataTable({
                    data: pendingData,
                    columns: [
                        { data: 'crid' },
                        { data: 'receiptPic' },
                        { data: 'subject' },
                        { data: 'student_name' },
                        { data: 'st_id' },
                        { data: 'course' },
                        {
                            data: 'null',
                            className: "view btn-outline-dark",
                            defaultContent: '<i class="bi bi-file-earmark-arrow-down"></i>',
                            orderable: false
                        },
                        {
                            data: 'null',
                            className: "approve ",
                            defaultContent: '<i class="bi bi-check-circle-fill"></i>',
                            orderable: false
                        },
                        {
                            data: 'null',
                            className: "reject",
                            defaultContent: '<i class="bi bi-x-circle-fill"></i>',
                            orderable: false
                        }


                    ],

                });


            }
        })


    });
}




$("#completionTable").on("click", "td.view", function (e) {

  var currentRow = $(this).closest("tr");
  // var col1 = currentRow.find("td:eq(0)").text(); // get current row 1st TD value
  var col2 = currentRow.find("td:eq(1)").text(); // get current row 2nd TD
  // var col3 = currentRow.find("td:eq(2)").text(); // get current row 3rd TD
  // var col4 = currentRow.find("td:eq(3)").text(); // get current row 4th TD
  // var col5 = currentRow.find("td:eq(4)").text(); // get current row 5th TD
  // var col6 = currentRow.find("td:eq(5)").text(); // get current row 6th TD

  

  //alert(col1 + " " + col2 + " " + col3 + " " + col4 + " " + col5 + " " + col6);

                      var receipt = col2;
                      download(receipt);


});

     function download(receipt){

      var element = document.createElement('a');
      element.setAttribute('href','./completionreceipt/'+receipt);
     element.setAttribute('download', receipt);
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);

     }



     
  $("#completionTable").on("click", "td.approve", function (e) {
    var currentRow = $(this).closest("tr");
    var col1 = currentRow.find("td:eq(0)").text(); // get current row 1st TD value


    $.ajax({
            url: "./sql_functions/update.pending.completion.php",
            dataType: "script",
            data:
            {
                id: col1,
                val: 'resolved'

            },
            success: function (data) {

                if(data == 0){
                    Swal.fire({
                        icon: "success",
                        title: "Completion Resolved",
                      });  

                      $('#completionTable').DataTable().clear().destroy();
                      setPendingTable();

                }
                else{
                    Swal.fire({
                        icon: "error",
                        title: "Unable to Resolved",
                      });  
                }


            }
        })
  })




  
  $("#completionTable").on("click", "td.reject", function (e) {
    var currentRow = $(this).closest("tr");
    var col1 = currentRow.find("td:eq(0)").text(); // get current row 1st TD value


    $.ajax({
            url: "./sql_functions/update.pending.completion.php",
            dataType: "script",
            data:
            {
                id: col1,
                val: 'rejected'

            },
            success: function (data) {

                if(data == 0){
                    Swal.fire({
                        icon: "success",
                        title: "Completion Rejected",
                      });  

                      $('#completionTable').DataTable().clear().destroy();
                      setPendingTable();

                }
                else{
                    Swal.fire({
                        icon: "error",
                        title: "Unable to Reject",
                      });  
                }


            }
        })
  })


