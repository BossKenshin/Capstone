$("#btn-logout-dept").click(function(){

    localStorage.clear();
    window.location.reload();
})

$("#btn-logout-admin").click(function(){

    localStorage.clear();
    window.location.reload();

})
$("#btn-logout-teacher").click(function(){

    localStorage.clear();
    window.location.reload();

})
$("#btn-logout-vice").click(function(){

   // document.cookie = "vp_id=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
   localStorage.clear();
   window.location.reload();

})


$("#btn-logout-student").click(function(){
    //document.cookie = "st_id=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    
    localStorage.clear();
    window.location.reload();

})