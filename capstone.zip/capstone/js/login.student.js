



$("#btn-login").click(function () {

var sid = document.getElementById("schoolid").value;
    

var format = /[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;


    if(!format.test(sid)){
$.ajax({
    url: "./sql_functions/login.student.php",
    type: "GET",
    data: {
        sid: sid
    }
})
    .done(function (data2) {

        let result = JSON.parse(data2);

        if (result.length != 0) {


            localStorage.setItem('st_id', result[0].sid);
            localStorage.setItem('st_course', result[0].cid);


            window.location.href = "./student.dashboard.php";

        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: "Your login credential don't match an account to the system",

            })
        }


    });


}

else{



}


})

