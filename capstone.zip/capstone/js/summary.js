
setNumTeacher();

function setNumTeacher() {

    $(document).ready(function () {

        $.ajax({
            url: "./sql_functions/fetch.teacher.php",
            success: function (data) {
                var teachersData = JSON.parse(data);

                    document.getElementById('num-teacher').innerHTML =  teachersData.length;

            }
        })


    });
}


setNumCourse();

//seting department table
function setNumCourse() {

    $(document).ready(function () {

        $.ajax({
            url: "./sql_functions/fetch.course.php",
            success: function (data) {
                courseData = JSON.parse(data);
        
                document.getElementById('num-course').innerHTML =  courseData.length;

            }
        })


    });
}


setNumDept();

//seting department table
function setNumDept() {

    $(document).ready(function () {

        $.ajax({
            url: "./sql_functions/fetch.department.php",
            success: function (data) {
                deptData = JSON.parse(data);
        
                document.getElementById('num-dept').innerHTML =  deptData.length;

            }
        })


    });
}



setNumSubject();

//seting department table
function setNumSubject() {

    $(document).ready(function () {

        $.ajax({
            url: "./sql_functions/fetch.subject.php",
            success: function (data) {
                subjectData = JSON.parse(data);
        
                document.getElementById('num-subject').innerHTML =  subjectData.length;

            }
        })


    });
}


setNumStudent();

//seting department table
function setNumStudent() {

    $(document).ready(function () {

        $.ajax({
            url: "./sql_functions/fetch.student.php",
            success: function (data) {
                studentData = JSON.parse(data);
        
                document.getElementById('num-student').innerHTML =  studentData.length;

            }
        })


    });
}



setNumFiles();

//seting department table
function setNumFiles() {

    $(document).ready(function () {

        $.ajax({
            url: "./sql_functions/fetch.gradefiles.php",
            success: function (data) {
                filesData = JSON.parse(data);
        
                document.getElementById('num-files').innerHTML =  filesData.length;

            }
        })


    });
}