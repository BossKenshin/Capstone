var did = localStorage.getItem('dept_id');

if(did ==  null){
  window.location.replace("./index.html");

}


setTeacherList();

function setTeacherList() {

    $(document).ready(function () {

        //var year = document.getElementById("StudentYear").value;


        $.ajax({
            url: "./sql_functions/fetch.teacher.list.php",
            data:
            {
                dept: did

            },
            success: function (data) {


                var pendingData = JSON.parse(data);


                $('#teacherList').DataTable({
                    data: pendingData,
                    columns: [
                        { data: 'fn' },
                        { data: 'mn' },
                        { data: 'ln' },
                        { data: 'username' },
                        { data: 'password' }

                    ]

                });


            }
        })


    });
}