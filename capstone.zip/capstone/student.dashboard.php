<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style/system.css">
    <link rel="stylesheet" href="gwa.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css">
    <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  </head>

<body>




<!-- Modal -->
<div class="modal fade" id="terms" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Terms and Agreement of Conditions</h1>
      </div>
      <div class="modal-body">
          
      <iframe src="./TermsandAgreementofConditions.pdf#toolbar=0"" height="1000" width="480"></iframe>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="terms-deny">Decline</button>
        <button type="button" class="btn btn-primary" id="terms-accept">Accept</button>
      </div>
    </div>
  </div>
</div>





  <div class="modal fade" tabindex="-1" id="modalSendReceipt">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Send Receipt</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <input type="file" name="" id="filePic" class="form-control" accept="jpg. , .jpeg , .png">

          <label for="typeReceipt"> Type of Receipt</label>
          <select class="form-select" aria-label="Default select example" id="typeReceipt">
            <option selected value="GWA">GWA</option>
            <option value="Prospectus">Prospectus</option>
            <option value="Completion">Completion</option>

          </select>

          <div class="row mt-3" id="hidden-row">
            <label for="completion-subject">Subject or Subject Code</label>
            <input type="text" class="form-control" name="" id="completion-subject">

            <label for="">Teacher</label>
            <br>
            <i>(type name of teacher. autosuggest)</i>
            <input class="form-control" type="text" list="teacherList" onfocus="setTeacherSearchBar()" name="" id="tname">

            <datalist id="teacherList">

            </datalist>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" id="sendReceipt">Send</button>
        </div>
      </div>
    </div>
  </div>



  <div class="modal fade" tabindex="-1" id="modalForGWA">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Information Needed</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <label for="yourname">FULL NAME</label>
          <input type="text" id="yourname" class="form-control" placeholder="LN,FN M">

          <label for="cl">COURSE/ LEVEL</label>
          <input type="text" id="cl" class="form-control" placeholder="Example: BSBA-FM1">

          <label for="sy">SCHOOL YEAR</label>
          <input type="text" id="sy" class="form-control" placeholder="Example: 2021-22">

          <label for="section">Section</label>
          <input type="text" id="section" class="form-control" placeholder="Example: BSBA-FM1B">

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" id="create-GWA">Send</button>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" tabindex="-1" id="modalForConcern">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Concerns Or Grade Problems</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">


          <label for="concernInput">Your concerns or grade related problems</label>
          <input type="text" id="concernInput" class="form-control" placeholder="Input here">


          <label for="">Teacher</label>
          <br>
          <i>(type name of teacher. autosuggest)</i>
          <input class="form-control" type="text" list="teacherConcernList" onfocus="setTeacherConcernBar()" name="" id="tcname">

          <datalist id="teacherConcernList">

          </datalist>


        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" id="send-Concern">Send</button>
        </div>
      </div>
    </div>
  </div>


  <div class="modal fade" id="modalNotification" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="staticBackdropLabel">Notifications</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" id="notif-body">




        </div>
      </div>
    </div>
  </div>



  <nav class="navbar navbar-expand-lg " id="navigation-bar">
    <div class="container-fluid">
      <a class="navbar-brand text-light" href="#">CRMC OGIS</a>
      <button class="navbar-toggler bg-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link text-white" aria-current="page" href="#">Home</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle  text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Send
            </a>
            <ul class="dropdown-menu ">
              <li><button class="dropdown-item " id="btn-send-receipt">Receipt</button></li>
              <li><button class="dropdown-item " id="btn-send-concern">Concerns</button></li>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle  text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Account
            </a>
            <ul class="dropdown-menu">
              <li><button class="dropdown-item" id="btn-view-notif">Notification</button></li>
              <li><button class="dropdown-item" id="btn-logout-student">Logout</button></li>
            </ul>
          </li>
        </ul>


      </div>
    </div>
  </nav>

  <template id="template">
    <tr id="data-row">
      <td class="data" id="subCode">asdf</td>
      <td class="data" id="subject">asdf</td>
      <td class="data" id="Grade">NG</td>
    </tr>

  </template>

  <template id="template-gwa">
    <tr id="data-row">
      <td class="data" id="code">asdf</td>
      <td class="data" id="desc">asdf</td>
      <td class="data" id="section">NG</td>
      <td class="data" id="units">asdf</td>
      <td class="data" id="rating">asdf</td>
      <td class="data" id="status">NG</td>
      <td class="data" id="offcode">NG</td>

    </tr>

  </template>


  <div class="container-fluid " id="whole-container">

    <div class="container bg-light mt-4 p-4 shadow">

      <div class="row">
        <div class="col-4">
          <p class="h4" id="name"></p>
        </div>
        <div class="col-4">
          <p class="h5" id="schoolid"></p>

        </div>
        <div class="col-4">
          <p class="h5" id="year"></p>

        </div>
      </div>
      <div class="row">
        <div class="col-4">
          <p class="h5" id="courseAbb"></p>
        </div>
        <div class="col-4">
          <p class="h5" id="department"></p>
        </div>
      </div>



      <div class="row mt-4" id="table-wrapper">

        <div class="col-sm-4">

          <label for="yearLevel"> Year Level</label>
          <select class="form-select" aria-label="Default select example" id="yearLevel">
            <option selected value="1st ">1st Year</option>
            <option value="2nd ">2nd Year</option>
            <option value="3rd ">3rd Year</option>
            <option value="4th ">4th Year</option>
          </select>
        </div>
        <div class="col-sm-4">

          <label for="semester"> Semester</label>
          <select class="form-select" aria-label="Default select example" id="semester">
            <option selected value="1st">1st</option>
            <option value="2nd">2nd</option>
            <option value="Summer">Summer</option>
          </select>
        </div>

        <div class="col-md-4 pt-4">
          <button class="btn btn-primary" onclick="loadSubjects()">Filter</button>
          <button class="btn " id="btn-GWA">GWA</button>
          <button class="btn " id="btn-prospectus">Prospectus</button>
        </div>





        <table class="display table text-center mt-5 w-100 border" id="GradesTable">
          <thead>
            <tr>

              <th>Subject</th>
              <th>Code</th>
              <th>Final Grade</th>
            </tr>


          </thead>

          <tbody>


          </tbody>
        </table>

      </div>


    </div>


  </div>




  <div id="bond-wrapper">

    <div class="top-div">

      <p class="school" style="font-weight: bold">CEBU ROOSEVELT MEMORIAL COLLEGES, INC.</p>
      <p class="address">San Vicente St. Bogo City, Cebu</p>
      <p class="tell">Tell #: (032) 434-8424/434-7365</p>
      <p class="school" style="font-weight: bold">REPORT ON RATINGS</p>
    </div>

    <div class="below-top-div">
      <div class="sem_sy">
        <p class="semy"> <span id="sem">Second Semester</span> <span id="schoolYear">School Year 2021-22</span> </p>

      </div>
      <div class="id_cl">
        <p> ID NUMBER: <span id="id">123214124</span></p>
        <p> COURSE/ LEVEL: <span id="courseLevel">BSBA-FM1</span> </p>
      </div>
      <div class="name">
        <p> NAME: <span id="st_name">ROSALES, JULIANA MAE P</span></p>
      </div>


    </div>
    <div class="table-div">


      <table id="gwaTable" style="width:100%">
        <thead>
          <tr>
            <th>SUBJECT</th>
            <th>DESCRIPTION</th>
            <th>SECTION</th>
            <th>UNITS</th>
            <th>RATINGS</th>
            <th>STATUS</th>
            <th>OFFER CODE</th>

          </tr>
        </thead>

        <tbody>


        </tbody>


      </table>

    </div>
    <div class="lower-div">

      <div class="signature">
        <p>Record Clerk: <span style="text-decoration: overline">Signature/ Date</span> </p>

      </div>
      <div class="gwa">
        <p style="font-weight: bolder;">GENERAL WEIGHTED AVERAGE: <span id="ave">1.5</span></p>
      </div>
      <div class="registrar">
        <p>NOTED BY: <span style="text-decoration: overline">JAC LESTER R. LEPTIEN (Registrar)</span></p>

      </div>

      <p>Print Date/Time: <span id="dt">2022/09/07 9:09:42</span></p>

    </div>


  </div>



  <script src="js/student.js"></script>
  <script src="js/generate.gwa.js"></script>
  <script src="js/logout.js"></script>


  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>


</body>

</html>