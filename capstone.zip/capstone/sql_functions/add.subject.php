<?php
include '/xampp/htdocs/capstone/dbconnect.php';

 

$name = $_GET['subject'];
$code =$_GET['code'];
$course =  str_replace( "'" ,"''",htmlspecialchars($_GET['course']));
$units =  str_replace( "'" ,"''",htmlspecialchars($_GET['units']));
$year =  str_replace( "'" ,"''",htmlspecialchars($_GET['year']));
$sem =  $_GET['sem'];






$inset_sub = "INSERT INTO `subject` (subject_name, subject_code, units,course_id, year_level, semester) 
VALUES ('$name', '$code','$units','$course','$year', '$sem')";

$res = mysqli_query($conn,$inset_sub);


if($res){
    echo "{\"res\" : \"success\"}";
}else{
   echo "{\"res\" : \"error\"}";
}

?>