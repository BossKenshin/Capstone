<?php
include '/xampp/htdocs/capstone/dbconnect.php';


$name = $_GET['fullname'];

$fetch_data = "SELECT concern_id, student_name, textValue FROM concern WHERE concern.status = 'pending' AND teacher_name = '$name'";



$res = mysqli_query($conn,$fetch_data);


$data = array();

while ($row = mysqli_fetch_assoc($res)) {
    $data[] = $row;
}


 echo json_encode($data);



?>