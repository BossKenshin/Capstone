<?php
include '/xampp/htdocs/capstone/dbconnect.php';
$type = $_GET['type'];


if($type == 'fetch'){

    $id = $_GET['id'];
    
    
    
    $update_student = "SELECT * FROM student WHERE student_schoolid = '$id' AND terms = 'accepted'";
    
    $res = mysqli_query($conn,$update_student);

    $row = mysqli_num_rows($res);
    
    
    if($row != 0){
      echo 0;
    }else{
       echo 1;
    }


}
else
{

    $id = $_GET['id'];
    
    
    
    $update_student = "UPDATE `student` SET `terms`='accepted' WHERE student_schoolid = '$id'";
    
    $ress = mysqli_query($conn,$update_student);
    
    
    if($ress){
      echo 0;
    }else{
       echo 1;
    }
}


?>