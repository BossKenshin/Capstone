<?php
include '/xampp/htdocs/capstone/dbconnect.php';


$ty = $_GET['typeOFnotic'];


if($ty == 'INC'){



$id = $_GET['id'];

$getinc = "SELECT subject_code FROM grades WHERE st_schoolid = '$id' AND grade = 'INC' ";

$res = mysqli_query($conn, $getinc);

$inc_arr = array();


while ($row = mysqli_fetch_assoc($res)) {
    $inc_arr[] = $row;
}


 echo json_encode($inc_arr);
}
else if($ty == 'receipt'){


    
$id = $_GET['id'];

$getinc = "SELECT receipt, print_status FROM admin_receipt WHERE st_id = '$id' AND print_status = 'approve' OR print_status = 'rejected'";

$res = mysqli_query($conn, $getinc);

$inc_arr = array();


while ($row = mysqli_fetch_assoc($res)) {
    $inc_arr[] = $row;
}


 echo json_encode($inc_arr);

}

?>