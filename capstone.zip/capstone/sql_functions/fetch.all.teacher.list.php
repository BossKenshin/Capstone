<?php
include '/xampp/htdocs/capstone/dbconnect.php';



$teacher = "SELECT  CONCAT(teacher_firstname,' ', teacher_middlename,' ',teacher_lastname) as fullname FROM teacher WHERE dl = 'active' ORDER BY  CONCAT(teacher_firstname,' ', teacher_middlename,' ',teacher_lastname) ASC;";
$res = mysqli_query($conn,$teacher);

$teacher_array = array();

while ($row = mysqli_fetch_assoc($res)) {
    $teacher_array[] = $row;
}


 echo json_encode($teacher_array);

?>