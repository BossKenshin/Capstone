<?php
include '/xampp/htdocs/capstone/dbconnect.php';


$ty = $_GET['checkType'];


if($ty == 'GWA'){



$id = $_GET['st_id'];

$getinc = "SELECT receipt FROM admin_receipt WHERE st_id = '$id' AND receipt = 'GWA' AND print_status = 'approve' ";

$res = mysqli_query($conn, $getinc);

if(mysqli_num_rows($res) > 0){
echo 0;
}
else{
    echo 1;
}


}
else if($ty == 'Prospectus'){




    $id = $_GET['st_id'];

    $getinc = "SELECT receipt FROM admin_receipt WHERE st_id = '$id' AND receipt = 'Prospectus' AND print_status = 'approve' ";
    
    $res = mysqli_query($conn, $getinc);
    
    if(mysqli_num_rows($res) > 0){
    echo 0;
    }
    else{
        echo 1;
    }
    

}

else{


    $id = $_GET['st_id'];

    $getPros = "SELECT `prosfilename` FROM `prospectus` 
    INNER JOIN student ON prospectus.course_id = student.student_courseID
    WHERE student.student_schoolid = '12341234';";
    
    $res = mysqli_query($conn, $getPros);

    $arr = array();
   
    while($row = mysqli_fetch_assoc($res)){
        $arr [] = $row;
    }

  echo  json_encode($arr);


}

?>