<?php
include '/xampp/htdocs/capstone/dbconnect.php';

$id = $_GET['id'];



$update_dept = "UPDATE department SET dl = 'hidden' WHERE dept_id = '$id'";

$res = mysqli_query($conn,$update_dept);


if($res){
    echo "{\"res\" : \"success\"}";
}else{
    echo "{\"res\" : \"error\"}";
}

?>