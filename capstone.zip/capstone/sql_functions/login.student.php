<?php
include '/xampp/htdocs/capstone/dbconnect.php';


session_start();

$sid = $_GET['sid'];

$sql_search = "SELECT  `student_schoolid` as sid, student_courseID as cid from student
 where `student_schoolid` = '$sid';";

$acc_arr = array();

$res1 = mysqli_query($conn, $sql_search);

while($row = mysqli_fetch_assoc($res1)){


    $acc_arr[] = $row;

}

   // $_SESSION['ssid'] = $row['sid'];

echo json_encode($acc_arr);


?>