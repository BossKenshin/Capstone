<?php
include '/xampp/htdocs/capstone/dbconnect.php';

$id = $_GET['id'];



$delete_teach = "UPDATE teacher SET dl = 'hidden' WHERE teacher_id = '$id' and dept_id != '24' ";

$res = mysqli_query($conn,$delete_teach);


if($res){
    echo "{\"res\" : \"success\"}";
}else{
    echo "{\"res\" : \"error\"}";
}

?>