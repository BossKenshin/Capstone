<?php
include '/xampp/htdocs/capstone/dbconnect.php';


$ty = $_GET['checkType'];


if($ty == 'GWA'){



$id = $_GET['st_id'];

$getinc = "DELETE from admin_receipt WHERE st_id = '$id' AND print_status = 'approve' AND receipt = 'GWA'";

$res = mysqli_query($conn, $getinc);

if($res){
echo 0;
}
else{
    echo 1;
}


}

else{





    $id = $_GET['st_id'];

    $getinc = "DELETE from admin_receipt WHERE st_id = '$id' AND print_status = 'approve' AND receipt = 'Prospectus'";
    
    $res = mysqli_query($conn, $getinc);
    
    if($res){
    echo 0;
    }
    else{
        echo 1;
    }
    
    

}


?>