<?php
include '/xampp/htdocs/capstone/dbconnect.php';


$type = $_POST['typeOfFunction'];


if($type == 'add'){

    
$file_tmp = $_FILES['file']['tmp_name'];

$file_name =  $_FILES['file']['name'];
$pdfFileName = str_replace(" ", "", $file_name);

$course = str_replace( "'" ,"''",htmlspecialchars($_POST['cid']));



    $insert = "INSERT INTO prospectus (course_id, prosfilename) VALUES('$course','$pdfFileName')";

    $result = mysqli_query($conn, $insert);

    if($result){
        move_uploaded_file($file_tmp,"C:/yyy/htdocs/capstone/prospectusfiles/".$pdfFileName);
        echo 0;
    }
    else{
        echo 1;
    }

}
else if($type == 'fetch'){


$sql_fetch = 'SELECT prosid as id, prosfilename, course.course_abbreviation as course_abb  FROM prospectus 
INNER JOIN course ON prospectus.course_id = course.course_id';

$file_arr = array();

$result = mysqli_query($conn,$sql_fetch );

while($row = mysqli_fetch_assoc($result)){

    $file_arr[] = $row;
}


echo json_encode($file_arr);


}
else{

    
$file_tmp = $_FILES['file']['tmp_name'];

$file_name =  $_FILES['file']['name'];
$pdfFileName = str_replace(" ", "", $file_name);

$course = str_replace( "'" ,"''",htmlspecialchars($_POST['cid']));

    $update = "UPDATE prospectus SET prosfilename ='$pdfFileName' WHERE course_id = '$course'";

    $result = mysqli_query($conn, $update);

    if($result){
        move_uploaded_file($file_tmp,"C:/yyy/htdocs/capstone/prospectusfiles/".$pdfFileName);
        echo 0;
    }
    else{
        echo 1;
    }

}



?>