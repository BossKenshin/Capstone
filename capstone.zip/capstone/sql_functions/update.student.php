<?php
include '/xampp/htdocs/capstone/dbconnect.php';

 
$id = str_replace( "'" ,"''",htmlspecialchars($_GET['id']));
$fn = $_GET['sfn'];
$ln = $_GET['sln'];
$mn = $_GET['smn'];
$sid = str_replace( "'" ,"''",htmlspecialchars($_GET['sid']));
$dept = str_replace( "'" ,"''",htmlspecialchars($_GET['dept']));
$course = str_replace( "'" ,"''",htmlspecialchars($_GET['course']));
$section =$_GET['section'];

$year = str_replace( "'" ,"''",htmlspecialchars($_GET['year']));




$update_student = "UPDATE student SET
 student_schoolid = '$sid', student_firstname = '$fn', student_lastname = '$ln',
  student_middlename = '$mn', student_deptID = '$dept', student_courseID = '$course',section = '$section' ,year_level = '$year'
  WHERE student_id = '$id'";

$res = mysqli_query($conn,$update_student);


if($res){
    echo "{\"res\" : \"success\"}";
}else{
   echo "{\"res\" : \"error\"}";
}

?>