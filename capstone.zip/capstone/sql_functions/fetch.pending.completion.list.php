<?php
include '/xampp/htdocs/capstone/dbconnect.php';


$name = $_GET['fullname'];

$fetch_data = "SELECT crid, receiptPic, subject, CONCAT(student.student_firstname,' ',student.student_middlename,' ', student.student_lastname) as student_name, student.student_schoolid as st_id, course, teacher_name FROM `completion_receipt`
INNER JOIN student ON completion_receipt.st_id = student.student_schoolid WHERE completion_receipt.status = 'pending' AND teacher_name = '$name'";



$res = mysqli_query($conn,$fetch_data);


$data = array();

while ($row = mysqli_fetch_assoc($res)) {
    $data[] = $row;
}


 echo json_encode($data);



?>