<?php
include '/xampp/htdocs/capstone/dbconnect.php';


$id = $_GET['id'];
$val = $_GET['val'];


$update_data = "UPDATE completion_receipt SET completion_receipt.status = '$val' WHERE crid = '$id'";



$res = mysqli_query($conn,$update_data);

if($res){
echo 0;
}
else{
echo 1;
}




?>