<?php
include '/xampp/htdocs/capstone/dbconnect.php';

$id = $_GET['id'];



$update = "UPDATE subject SET dl = 'hidden' WHERE subject_id = '$id'";


$res = mysqli_query($conn,$update);



if($res){
    echo "{\"res\" : \"success\"}";
}else{
    echo "{\"res\" : \"error\"}";
}

?>