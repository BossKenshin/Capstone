<?php
include '/xampp/htdocs/capstone/dbconnect.php';

$tid = $_GET['tid'];

$fetch_data = "SELECT CONCAT(teacher_firstname,' ',teacher_middlename,' ',teacher_lastname) as teacher_name FROM teacher WHERE teacher_id = '$tid' AND teacher.dl = 'active'";

$res = mysqli_query($conn,$fetch_data);


$data = array();

while ($row = mysqli_fetch_assoc($res)) {
    $data[] = $row;
}


 echo json_encode($data);

?>