<?php
include '/xampp/htdocs/capstone/dbconnect.php';

$id = str_replace( "'" ,"''",htmlspecialchars($_GET['id']));


$app_sql = "UPDATE gradefiles SET admin_status = 'approved'  WHERE gfid = '$id'";


$res = mysqli_query($conn,$app_sql);

if($res){
echo 0;
}
else{
    echo 1;
}

?>