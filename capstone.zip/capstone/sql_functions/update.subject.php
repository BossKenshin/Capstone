<?php
include '/xampp/htdocs/capstone/dbconnect.php';

 

$sid = str_replace( "'" ,"''",htmlspecialchars($_GET['id']));
$name = $_GET['name'];
$code =$_GET['code'];
$course =  str_replace( "'" ,"''",htmlspecialchars($_GET['course']));
$units =  str_replace( "'" ,"''",htmlspecialchars($_GET['units']));
$year =  str_replace( "'" ,"''",htmlspecialchars($_GET['year']));
$sem =  $_GET['sem'];



$inset_sub = "UPDATE `subject` SET `subject_code`= '$code',`subject_name`= '$name', course_id = '$course',units = '$units' ,year_level = '$year', semester = '$sem' WHERE `subject_id`= '$sid';";

$res = mysqli_query($conn,$inset_sub);


if($res){
    echo "{\"res\" : \"success\"}";
}else{
   echo "{\"res\" : \"error\"}";
}

?>